from django.db import models

class todoitem(models.Model):
   content = models.TextField()
   content = models.TextField()
   content = models.TextField()
   content = models.TextField()


class todoproducts(models.Model):
   content = models.TextField()
   content = models.TextField()
   content = models.TextField()
   content = models.TextField()
   content = models.TextField()
   content = models.TextField()
   content = models.TextField()
   content = models.TextField()
   content = models.TextField()
   content = models.TextField()
   content = models.TextField()
   content = models.TextField()
   content = models.TextField()
   content = models.TextField()


# Create your models here.
