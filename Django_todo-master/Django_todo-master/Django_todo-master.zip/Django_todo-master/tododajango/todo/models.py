from django.db import models

class todoitem(models.Model):
    content=models.TextField()

# Create your models here.
