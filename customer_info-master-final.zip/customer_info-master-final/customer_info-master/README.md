# customer_info
using django frame work design for customer details and product details
